/*****************************************************************************/
/*  llmpy.c v4.4.1                                                           */
/*                                                                           */
/* Copyright (c) 2000-2012 Texas Instruments Incorporated                    */
/* http://www.ti.com/                                                        */
/*                                                                           */
/*  Redistribution and  use in source  and binary forms, with  or without    */
/*  modification,  are permitted provided  that the  following conditions    */
/*  are met:                                                                 */
/*                                                                           */
/*     Redistributions  of source  code must  retain the  above copyright    */
/*     notice, this list of conditions and the following disclaimer.         */
/*                                                                           */
/*     Redistributions in binary form  must reproduce the above copyright    */
/*     notice, this  list of conditions  and the following  disclaimer in    */
/*     the  documentation  and/or   other  materials  provided  with  the    */
/*     distribution.                                                         */
/*                                                                           */
/*     Neither the  name of Texas Instruments Incorporated  nor the names    */
/*     of its  contributors may  be used to  endorse or  promote products    */
/*     derived  from   this  software  without   specific  prior  written    */
/*     permission.                                                           */
/*                                                                           */
/*  THIS SOFTWARE  IS PROVIDED BY THE COPYRIGHT  HOLDERS AND CONTRIBUTORS    */
/*  "AS IS"  AND ANY  EXPRESS OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT    */
/*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR    */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT    */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/*  SPECIAL,  EXEMPLARY,  OR CONSEQUENTIAL  DAMAGES  (INCLUDING, BUT  NOT    */
/*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,    */
/*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    */
/*  THEORY OF  LIABILITY, WHETHER IN CONTRACT, STRICT  LIABILITY, OR TORT    */
/*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE    */
/*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.     */
/*                                                                           */
/*****************************************************************************/

typedef long long int40_t;
typedef unsigned long long uint40_t;

typedef unsigned int uint;
typedef unsigned long ulong;

int40_t _mpylli(register int40_t src1, register int40_t src2)
{
    register ulong low, mid, high;

    /*-----------------------------------------------------------------------*/
    /* These 16x16->32 multiplies must be unsigned if anything but the	     */
    /* lower 16 bits of the result is used in the answer.  This is only	     */
    /* true for the low part.  In theory, multiplications involving the	     */
    /* high parts (which contain the sign bits) should be done as mixed	     */
    /* signed/unsigned multiplies, but the bits which would differ are	     */
    /* ignored anyway.  Thus, doing everything in unsigned arithmetic is     */
    /* safe, and for the C55x compiler more efficient.			     */
    /*-----------------------------------------------------------------------*/
    low  = ((ulong)(uint)src1         * (uint)src2);
    mid  = ((ulong)(uint)(src1 >> 16) * (uint)src2 + 
	    (ulong)(uint)src1         * (uint)(src2 >> 16));
    high = ((ulong)(uint)(src1 >> 32) * (uint)src2 + 
	    (ulong)(uint)(src1 >> 16) * (uint)(src2 >> 16) +
	    (ulong)(uint)src1         * (uint)(src2 >> 32));

    return ((ulong)low + ((uint40_t)mid << 16) + ((uint40_t)high << 32));
}

/* the 80-bit divmod style is dangerous if bit(unsigned dividend, 39)==1. */

uint40_t _divull(register uint40_t a, register uint40_t b)
{
    register uint40_t _a  = a;
    register uint40_t _b  = b;
    register uint40_t lmb = 1ull << 39;
    register uint40_t q;

    register int      rshift, lshift;
 
    if (_b > _a || _b == 0) return 0;
 
    /*-----------------------------------------------------------------------*/
    /* COMPUTE DIFFERENCE IN POSITIONS OF MSBs, AND ALIGN THEM.              */
    /*-----------------------------------------------------------------------*/
    for (rshift = 0; (_a & lmb) == 0; ++rshift) lmb >>= 1;
    for (lshift = 0; (_b & lmb) == 0; ++lshift) _b  <<= 1;
 
    q = 0;

    /*-----------------------------------------------------------------------*/
    /* DIVIDE USING CONDITIONAL SUBTRACTION.                                 */
    /*-----------------------------------------------------------------------*/
    do
    {
	q <<= 1;
	if (_a >= _b) { _a -= _b; q |= 1; }
 
	if (rshift++ == 0) _b >>= 1;
	else               _a <<= 1;
 
    } while (lshift--);

    return q;
}

uint40_t _remull(register uint40_t a, register uint40_t b)
{
    return a - a / b * b;
}

int40_t _divlli(register int40_t a, register int40_t b)
{
    int    sign_a = a < 0;
    int    sign_b = b < 0;

    int40_t  res;

    uint40_t au = (sign_a) ? -a : a;
    uint40_t bu = (sign_b) ? -b : b;

    res = au / bu;

    return (sign_a ^ sign_b) ? -res : res;
}

int40_t _remlli(register int40_t a, register int40_t b)
{
    int    sign_a = a < 0;
    int    sign_b = b < 0;

    int40_t  res;

    uint40_t au = (sign_a) ? -a : a;
    uint40_t bu = (sign_b) ? -b : b;

    res = au % bu;

    return (sign_a) ? -res : res;
}
