/*****************************************************************************/
/* cpy_tbl.c  v4.4.1                                                         */
/*                                                                           */
/* Copyright (c) 2003-2012 Texas Instruments Incorporated                    */
/* http://www.ti.com/                                                        */
/*                                                                           */
/*  Redistribution and  use in source  and binary forms, with  or without    */
/*  modification,  are permitted provided  that the  following conditions    */
/*  are met:                                                                 */
/*                                                                           */
/*     Redistributions  of source  code must  retain the  above copyright    */
/*     notice, this list of conditions and the following disclaimer.         */
/*                                                                           */
/*     Redistributions in binary form  must reproduce the above copyright    */
/*     notice, this  list of conditions  and the following  disclaimer in    */
/*     the  documentation  and/or   other  materials  provided  with  the    */
/*     distribution.                                                         */
/*                                                                           */
/*     Neither the  name of Texas Instruments Incorporated  nor the names    */
/*     of its  contributors may  be used to  endorse or  promote products    */
/*     derived  from   this  software  without   specific  prior  written    */
/*     permission.                                                           */
/*                                                                           */
/*  THIS SOFTWARE  IS PROVIDED BY THE COPYRIGHT  HOLDERS AND CONTRIBUTORS    */
/*  "AS IS"  AND ANY  EXPRESS OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT    */
/*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR    */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT    */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/*  SPECIAL,  EXEMPLARY,  OR CONSEQUENTIAL  DAMAGES  (INCLUDING, BUT  NOT    */
/*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,    */
/*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    */
/*  THEORY OF  LIABILITY, WHETHER IN CONTRACT, STRICT  LIABILITY, OR TORT    */
/*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE    */
/*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.     */
/*                                                                           */
/*                                                                           */
/* General purpose copy routine.  Given the address of a linker-generated    */
/* COPY_TABLE data structure, effect the copy of all object components       */
/* that are designated for copy via the corresponding LCF table() operator.  */
/*                                                                           */
/*****************************************************************************/
#include <cpy_tbl.h>

#define INT_COUNT(x) (((x) + (sizeof(int)-1))/sizeof(int))

/*****************************************************************************/
/* MEMCPY_II() - Copy data from one I/O location to another.                 */
/*****************************************************************************/
static __ioport void *memcpy_ii(__ioport void       *to, 
                                const __ioport void *from, 
			        size_t               n)
{
    __ioport int *rto   = (__ioport int *) to;
    __ioport int *rfrom = (__ioport int *) from;
    size_t rn;

    for (rn = 0; rn < INT_COUNT(n); rn++) *rto++ = *rfrom++;
    return (to);
}

/*****************************************************************************/
/* MEMCPY_IM() - Copy data from an I/O location to memory.                   */
/*****************************************************************************/
static __ioport void *memcpy_im(void                *to, 
                                const __ioport void *from, 
			        size_t               n)
{
    int          *rto   = (int *) to;
    __ioport int *rfrom = (__ioport int *) from;
    size_t rn;

    for (rn = 0; rn < INT_COUNT(n); rn++) *rto++ = *rfrom++;
    return (to);
}

/*****************************************************************************/
/* MEMCPY_MI() - Copy data from memory to an I/O location.                   */
/*****************************************************************************/
static __ioport void *memcpy_mi(__ioport void *to, 
                                const void    *from, 
			        size_t         n)
{
    __ioport int *rto   = (__ioport int *) to;
    int          *rfrom = (int *) from;
    size_t rn;

    for (rn = 0; rn < INT_COUNT(n); rn++) *rto++ = *rfrom++;
    return (to);
}

/*****************************************************************************/
/* _COPY_IN()                                                                 */
/*****************************************************************************/
void _copy_in(COPY_TABLE *tp)
{
   unsigned short i;
   for (i = 0; i < tp->num_recs; i++)
   {
      COPY_RECORD   *crp       = &tp->recs[i];
      int            load_pgid = (int)(crp->load_loc >> 24);
#pragma diag_suppress 1107
      unsigned char *load_addr = (unsigned char *)(crp->load_loc & 0x7fffff);
      int            run_pgid  = (int)(crp->run_loc >> 24);
      unsigned char *run_addr  = (unsigned char *)(crp->run_loc & 0x7fffff);
#pragma diag_default 1107
      unsigned int   cpy_type  = 0;

      /***********************************************************************/
      /* If page ID != 0, location is assumed to be in I/O memory.           */
      /***********************************************************************/
      if (load_pgid) cpy_type += 2;
      if (run_pgid)  cpy_type += 1;
      
      /***********************************************************************/
      /* Dispatch to appropriate copy routine based on whether or not load   */
      /* and/or run location is in I/O memory.                               */
      /***********************************************************************/
      switch (cpy_type)
      {
         case 3: memcpy_ii(load_addr, run_addr, crp->size); break;
         case 2: memcpy_im(load_addr, run_addr, crp->size); break;
         case 1: memcpy_mi(load_addr, run_addr, crp->size); break;

         case 0: memcpy(run_addr, load_addr, crp->size); break;
      }
   }            
}

