/****************************************************************************/
/*  ld3.h           v4.4.1                                                  */
/*                                                                          */
/* Copyright (c) 2007-2012 Texas Instruments Incorporated                   */
/* http://www.ti.com/                                                       */
/*                                                                          */
/*  Redistribution and  use in source  and binary forms, with  or without   */
/*  modification,  are permitted provided  that the  following conditions   */
/*  are met:                                                                */
/*                                                                          */
/*     Redistributions  of source  code must  retain the  above copyright   */
/*     notice, this list of conditions and the following disclaimer.        */
/*                                                                          */
/*     Redistributions in binary form  must reproduce the above copyright   */
/*     notice, this  list of conditions  and the following  disclaimer in   */
/*     the  documentation  and/or   other  materials  provided  with  the   */
/*     distribution.                                                        */
/*                                                                          */
/*     Neither the  name of Texas Instruments Incorporated  nor the names   */
/*     of its  contributors may  be used to  endorse or  promote products   */
/*     derived  from   this  software  without   specific  prior  written   */
/*     permission.                                                          */
/*                                                                          */
/*  THIS SOFTWARE  IS PROVIDED BY THE COPYRIGHT  HOLDERS AND CONTRIBUTORS   */
/*  "AS IS"  AND ANY  EXPRESS OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT   */
/*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT   */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   */
/*  SPECIAL,  EXEMPLARY,  OR CONSEQUENTIAL  DAMAGES  (INCLUDING, BUT  NOT   */
/*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   */
/*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   */
/*  THEORY OF  LIABILITY, WHETHER IN CONTRACT, STRICT  LIABILITY, OR TORT   */
/*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   */
/*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    */
/*                                                                          */
/****************************************************************************/

#ifndef __LD3_H__
#define __LD3_H__

/*---------------------------------------------------------------------------*/
/* TMS320C55xx-specific 32-bit REAL (and other) behavior descriptions.       */
/*---------------------------------------------------------------------------*/
#include <stdint.h>

#define Adds_Per_Add  1  /* ratio of REAL add  to add */
#define Adds_Per_Mult 10 /* ratio of REAL mult to add */
#define Adds_Per_Div  50 /* ratio of REAL div  to add */

#define FLT_FIX_Faster_Than_MODF 1 /* (float)((int(x))) faster than modf */

#define Floating_Sub_Has_Guard_Digit 0 /* safe value is 0 */

#undef Support_DENORM     /* denormalized numbers             */
#define Support_INFNAN	 /*  INFINITY's and NAN's                */
#undef Support_SATURATION /* saturate overflows to MOST_POS,MOST_NEG */

#define INT_MOST_POS_P1 CNST( 32768.0) /* most pos int +1 as REAL */
#define INT_MOST_NEG    CNST(-32768.0) /* most neg int    as REAL */
#define INT_MOST_NEG_M1 CNST(-32769.0) /* most neg int -1 as REAL */

#ifdef  __TMS320C55X_PLUS_BYTE__
#define BPAU 8
#define BPchar 8
#else
#define BPAU 16   /* bits per Addressable Unit                  */
#define BPchar 16 /* bits per char                              */
#endif
#define BPshrt 16 /* bits per short                             */
#define BPint 16  /* bits per int                               */
#define BPlong 32 /* bits per long (0 if not supported)         */
#define BPlonglong 40 /* bits per long long (0 if not supported)         */

#define BPfloat 32
#define BPdouble 32
#define BPlongdouble 32

#define MSB_In_Hi_Addr 0 /* ENDIANness. 0=big, 1=little */

typedef union{
  float f;
  struct{
    uint_least8_t sign:1;
    uint32_t exp:8;
    uint32_t mantissa:23;
  }fp_format;
}FLOAT2FORM;

typedef union{
  double f;
  struct{
    uint_least8_t sign:1;
    uint32_t exp:8;
    uint32_t mantissa:23;
  }fp_format;
}DOUBLE2FORM;


#define FLOAT_TO_REALNUM(x, y) \
do{\
FLOAT2FORM xx; \
xx.f = x; \
y.sign = xx.fp_format.sign; \
y.exp = xx.fp_format.exp - 127; \
y.mantissa = 0x80000000 | (xx.fp_format.mantissa << 8); \
}while(0)

#define REALNUM_TO_FLOAT(x, y) \
do{ \
FLOAT2FORM xx; \
xx.fp_format.sign = x.sign; \
xx.fp_format.exp = x.exp + 127; \
xx.fp_format.mantissa = (x.mantissa << 1) >> 9; \
y = xx.f; \
}while(0)

#define DOUBLE_TO_REALNUM(x, y) \
do{\
DOUBLE2FORM xx; \
xx.f = x; \
y.sign = xx.fp_format.sign; \
y.exp = xx.fp_format.exp - 127; \
y.mantissa = 0x80000000 | (xx.fp_format.mantissa << 8); \
}while(0)

#define REALNUM_TO_DOUBLE(x, y) \
do{ \
DOUBLE2FORM xx; \
xx.fp_format.sign = x.sign; \
xx.fp_format.exp = x.exp + 127; \
xx.fp_format.mantissa = (x.mantissa << 1) >> 9; \
y = xx.f; \
}while(0)

/*if doubles are changed to be double precision instead of single precision
 *then the realnum format will no longer work since ld3 does not have an
 *integer type that can hold a 53 bit mantissa. The solution would be to
 *change the mantissa_t type to an array and change the DOUBLE_TO_REALNUM macro
 *as follows:

 #define DOUBLE_TO_REALNUM(x, y) \
 do{\
 DOUBLE2FORM xx; \
 mantissa_t m[2];
 xx.f = x; \
 y.sign = xx.fp_format.sign; \
 y.exp = xx.fp_format.exp - 127; \
 y.mantissa[0] = xx.fp_format.mantissa0;
 y.mantissa[1] = xx.fp_format.mantissa1;
 }while(0)

 *the DOUBLE2FORM union would need to be changed also, but this should be easy
 *With this macro we would then have a mantissa that can be as long as needed,
 *and we did not have to use malloc.
 */

#endif
